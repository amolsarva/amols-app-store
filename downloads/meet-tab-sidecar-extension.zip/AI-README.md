# AI-README: meet-tab-sidecar-extension

> **AI instructions for this folder**
> 1. Read the master guide first: `~/Documents/root/AI-README.md`, then `../AGENTS.md` (mac-scripts layout + touch protocol).
> 2. Read this file.
> 3. Before you finish, **append your learnings** to the *Learnings* section below, dated. Don't rely on chat memory.

> **⚠️ mac-scripts touch protocol.** This folder is part of `~/Documents/root/mac-scripts`, which feeds a public GitHub repo, amolsarva.com/scripts, the Backstage download + update feed, and copies installed on every Mac (LaunchAgents, apps, git hooks). Any change here → follow the **Touch protocol** in `../AGENTS.md`: update this tool's `tool.json` (incl. `installs`/`artifacts`) and README, use `../python-guard` for any Python, then run `../supporting-files/publish/release.sh --go` (or Backstage ▸ Release mac-scripts). In a sandbox that can't: run the dry run, fix what it reports, and ask Amol to press the button.

## What this folder is
Chrome extension for joining a Meet while a sidecar tab handles audio, intros, or presentation work.

Status: `public` (only Amol changes review → public).

## Learnings (append, newest first, dated)
- 2026-10-17: AI-README created during the mac-scripts consolidation (python-guard, release.sh, installs/artifacts in tool.json).
